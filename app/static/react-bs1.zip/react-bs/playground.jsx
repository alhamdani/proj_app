var Message = React.createClass({
  render: function(){
    return (
      
      <div>
        <p className='text'>easydevtuts</p>
        <p className='text'>tutorials</p>
      </div>

    );
  }
});

React.render(<Message />, document.getElementById('demo'));
